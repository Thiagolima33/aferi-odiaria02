# Aferição Diária — Vercel (Config corrigida)
- `vercel.json` usa version 2 (builds + routes) e envia `/` para `/frontend/index.html`.

## Variáveis no Vercel
DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, JWT_SECRET

## Login de teste
Email: thiago@mc-engenharia.com
Senha: 123456
