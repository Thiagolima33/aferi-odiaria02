const jwt = require('jsonwebtoken');
function requireAuth(req){
  const auth = req.headers.authorization || '';
  const token = auth.replace('Bearer ','').trim();
  if(!token) throw new Error('Sem token');
  const payload = jwt.verify(token, process.env.JWT_SECRET);
  return payload;
}
module.exports = { requireAuth };