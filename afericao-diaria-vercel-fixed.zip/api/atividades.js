const { getPool } = require('./_db.js');
const { requireAuth } = require('./_auth.js');
module.exports = async (req, res) => {
  try{
    requireAuth(req);
    const pool = getPool();
    if (req.method === 'GET'){
      const obra_id = req.query.obra_id;
      const [rows] = await pool.query('SELECT id, nome FROM atividades WHERE obra_id = ?', [obra_id]);
      return res.status(200).json(rows);
    }
    if (req.method === 'POST'){
      const { obra_id, nome } = req.body || {};
      await pool.query('INSERT INTO atividades (obra_id, nome) VALUES (?,?)', [obra_id, nome]);
      return res.status(200).json({ ok:true });
    }
    res.status(405).json({ error: 'Método inválido' });
  }catch(e){ res.status(401).json({ error: e.message }); }
};