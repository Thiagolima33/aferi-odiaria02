const jwt = require('jsonwebtoken');
const { getPool } = require('./_db.js');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método inválido' });
  try{
    const { email, senha } = req.body || {};
    const pool = getPool();
    const [rows] = await pool.query('SELECT id, nome, email, senha_hash, funcao FROM usuarios WHERE email = ?', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Usuário não encontrado' });
    const u = rows[0];
    if (u.senha_hash !== senha) return res.status(401).json({ error: 'Senha inválida' });
    const token = jwt.sign({ sub: u.id, funcao: u.funcao }, process.env.JWT_SECRET, { expiresIn: '8h' });
    res.status(200).json({ token, usuario: { id: u.id, nome: u.nome, email: u.email, funcao: u.funcao } });
  }catch(e){ res.status(500).json({ error: e.message }); }
};