const { getPool } = require('./_db.js');
const { requireAuth } = require('./_auth.js');
module.exports = async (req, res) => {
  try{
    requireAuth(req);
    const pool = getPool();
    if (req.method === 'GET'){
      const [rows] = await pool.query('SELECT id, nome FROM obras ORDER BY id DESC');
      return res.status(200).json(rows);
    }
    if (req.method === 'POST'){
      const { nome, local } = req.body || {};
      await pool.query('INSERT INTO obras (nome, local) VALUES (?,?)', [nome, local||'']);
      return res.status(200).json({ ok:true });
    }
    res.status(405).json({ error: 'Método inválido' });
  }catch(e){ res.status(401).json({ error: e.message }); }
};