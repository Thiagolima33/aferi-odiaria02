const { getPool } = require('./_db.js');
const { requireAuth } = require('./_auth.js');
module.exports = async (req, res) => {
  try{
    const user = requireAuth(req);
    const pool = getPool();
    if (req.method === 'GET'){
      const obra_id = req.query.obra_id || '%';
      const usuario_like = (req.query.usuario_like||'').trim();
      const de = req.query.de || '0000-01-01';
      const ate = req.query.ate || '9999-12-31';
      const atividade_like = (req.query.atividade_like||'').trim();
      const [rows] = await pool.query(
        `SELECT p.id, p.quantidade, DATE_FORMAT(p.data,'%Y-%m-%d') as data, p.anotacoes,
                u.nome as usuario, o.nome as obra, a.nome as atividade
         FROM producao p
         JOIN usuarios u ON u.id = p.usuario_id
         JOIN obras o ON o.id = p.obra_id
         JOIN atividades a ON a.id = p.atividade_id
         WHERE ( ? = '%' OR p.obra_id = ? )
           AND ( u.nome LIKE CONCAT('%',?,'%') OR u.email LIKE CONCAT('%',?,'%') )
           AND ( a.nome LIKE CONCAT('%',?,'%') )
           AND p.data BETWEEN ? AND ?
         ORDER BY p.data DESC`,
        [obra_id, obra_id, usuario_like, usuario_like, atividade_like, de, ate]
      );
      return res.status(200).json(rows);
    }
    if (req.method === 'POST'){
      const { obra_id, atividade_id, quantidade, data, anotacoes } = req.body || {};
      await pool.query('INSERT INTO producao (usuario_id, obra_id, atividade_id, quantidade, data, anotacoes) VALUES (?,?,?,?,?,?)',
        [user.sub, obra_id, atividade_id, quantidade, data, anotacoes||'']);
      return res.status(200).json({ ok:true });
    }
    res.status(405).json({ error: 'Método inválido' });
  }catch(e){ res.status(401).json({ error: e.message }); }
};