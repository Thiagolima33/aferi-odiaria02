# Aferição Diária — Deploy no Vercel (com MariaDB)
(veja instruções no README criado anteriormente; configure variáveis de ambiente DB_* e JWT_SECRET)
