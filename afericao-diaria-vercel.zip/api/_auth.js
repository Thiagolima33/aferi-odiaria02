import jwt from 'jsonwebtoken';
export function requireAuth(req){
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace('Bearer ','').trim();
  if(!token) throw new Error('Sem token');
  const payload = jwt.verify(token, process.env.JWT_SECRET);
  return payload;
}
