import jwt from 'jsonwebtoken';
import { getPool } from './_db.js';
export const config = { runtime: 'edge' };
export default async function handler(req){
  if (req.method !== 'POST') return new Response(JSON.stringify({error:'Método inválido'}), {status:405});
  try{
    const { email, senha } = await req.json();
    const pool = await getPool();
    const [rows] = await pool.query('SELECT id, nome, email, senha_hash, funcao FROM usuarios WHERE email = ?', [email]);
    if (!rows.length) return new Response(JSON.stringify({error:'Usuário não encontrado'}), {status:401});
    const u = rows[0];
    if (u.senha_hash !== senha) return new Response(JSON.stringify({error:'Senha inválida'}), {status:401});
    const token = jwt.sign({sub:u.id, funcao:u.funcao}, process.env.JWT_SECRET, {expiresIn:'8h'});
    return new Response(JSON.stringify({ token, usuario: { id:u.id, nome:u.nome, email:u.email, funcao:u.funcao } }), {status:200, headers:{'Content-Type':'application/json'}});
  }catch(e){ return new Response(JSON.stringify({error:e.message}), {status:500}); }
}
