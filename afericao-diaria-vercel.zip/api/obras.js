import { getPool } from './_db.js';
import { requireAuth } from './_auth.js';
export const config = { runtime: 'edge' };
export default async function handler(req){
  try{
    const user = requireAuth(req);
    const pool = await getPool();
    if (req.method === 'GET'){
      const [rows] = await pool.query('SELECT id, nome FROM obras ORDER BY id DESC');
      return new Response(JSON.stringify(rows), {status:200, headers:{'Content-Type':'application/json'}});
    }
    if (req.method === 'POST'){
      const body = await req.json();
      await pool.query('INSERT INTO obras (nome, local) VALUES (?,?)', [body.nome, body.local||'']);
      return new Response(JSON.stringify({ok:true}), {status:200});
    }
    return new Response(JSON.stringify({error:'Método inválido'}), {status:405});
  }catch(e){ return new Response(JSON.stringify({error:e.message}), {status:401}); }
}
