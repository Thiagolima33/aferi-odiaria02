import { getPool } from './_db.js';
import { requireAuth } from './_auth.js';
export const config = { runtime: 'edge' };
export default async function handler(req){
  try{
    const user = requireAuth(req);
    const pool = await getPool();
    if (req.method === 'GET'){
      const url = new URL(req.url);
      const obra_id = url.searchParams.get('obra_id') || '%';
      const usuario_like = (url.searchParams.get('usuario_like')||'').trim();
      const de = url.searchParams.get('de') || '0000-01-01';
      const ate = url.searchParams.get('ate') || '9999-12-31';
      const atividade_like = (url.searchParams.get('atividade_like')||'').trim();
      const [rows] = await pool.query(
        `SELECT p.id, p.quantidade, DATE_FORMAT(p.data,'%Y-%m-%d') as data, p.anotacoes,
                u.nome as usuario, o.nome as obra, a.nome as atividade
         FROM producao p
         JOIN usuarios u ON u.id = p.usuario_id
         JOIN obras o ON o.id = p.obra_id
         JOIN atividades a ON a.id = p.atividade_id
         WHERE ( ? = '%' OR p.obra_id = ? )
           AND ( u.nome LIKE CONCAT('%',?,'%') OR u.email LIKE CONCAT('%',?,'%') )
           AND ( a.nome LIKE CONCAT('%',?,'%') )
           AND p.data BETWEEN ? AND ?
         ORDER BY p.data DESC`,
        [obra_id, obra_id, usuario_like, usuario_like, atividade_like, de, ate]
      );
      return new Response(JSON.stringify(rows), {status:200, headers:{'Content-Type':'application/json'}});
    }
    if (req.method === 'POST'){
      const body = await req.json();
      await pool.query('INSERT INTO producao (usuario_id, obra_id, atividade_id, quantidade, data, anotacoes) VALUES (?,?,?,?,?,?)',
        [user.sub, body.obra_id, body.atividade_id, body.quantidade, body.data, body.anotacoes||'']);
      return new Response(JSON.stringify({ok:true}), {status:200});
    }
    return new Response(JSON.stringify({error:'Método inválido'}), {status:405});
  }catch(e){ return new Response(JSON.stringify({error:e.message}), {status:401}); }
}
